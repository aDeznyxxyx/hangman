﻿// See https://aka.ms/new-console-template for more information

using HangmanGame;

var state = new State();


while (state.HasLives())
{
    state.Draw();
    var input = Console.ReadLine();
    state.Process(input!);
}