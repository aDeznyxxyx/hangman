﻿namespace HangmanGame;

public class State
{
    private List<char> _guessedLetters;
    private string _currentWord;
    private int _lives;
    
    public State()
    {
        _lives = 5;
    }
    
    public void Draw()
    {
        
    }

    public void Process(char input)
    {
        
    }

    public bool HasLives()
    {
        return false;
    }
}